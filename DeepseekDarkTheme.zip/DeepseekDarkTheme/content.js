// Apply theme to dynamically loaded content
const observer = new MutationObserver((mutations) => {
  applyThemeStyles();
});

observer.observe(document.body, {
  childList: true,
  subtree: true,
  attributes: true,
});

function applyThemeStyles() {
  // Apply background to all divs
  document.querySelectorAll('div').forEach(el => {
    if (!el.style.backgroundColor || el.style.backgroundColor === 'transparent') {
      el.style.backgroundColor = 'var(--ds-bg) !important';
    }
  });

  // Fix code blocks
  document.querySelectorAll('pre, code').forEach(el => {
    el.style.backgroundColor = '#1A1A1A';
    el.style.border = '1px solid #333';
  });
}

// Initial application
document.addEventListener('DOMContentLoaded', applyThemeStyles);